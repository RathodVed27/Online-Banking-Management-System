import { ReactNode } from "react";
import Header from "./Header";
import Footer from "./Footer";

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-[hsl(var(--background))] text-[hsl(var(--foreground))]">
      <Header />
      <main className="container mx-auto px-6 py-6 max-w-7xl">{children}</main>
      <Footer />
    </div>
  );
}
