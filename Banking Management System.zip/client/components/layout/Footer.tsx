export default function Footer() {
  return (
    <footer className="mt-10 border-t border-[hsl(var(--border))] bg-white/70">
      <div className="container mx-auto max-w-7xl px-6 py-6 text-sm text-muted-foreground flex flex-col md:flex-row items-center justify-between gap-4">
        <p>© {new Date().getFullYear()} BankFlow Pro. All rights reserved.</p>
        <div className="flex items-center gap-4">
          <a className="hover:text-foreground" href="#">Privacy</a>
          <a className="hover:text-foreground" href="#">Terms</a>
          <a className="hover:text-foreground" href="#">Support</a>
        </div>
      </div>
    </footer>
  );
}
