import { Link, NavLink, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Banknote, CreditCard, History, Home, LogOut, Settings as IconSettings, Shuffle, User } from "lucide-react";

const navItems = [
  { label: "Dashboard", to: "/", icon: Home },
  { label: "Transfers", to: "/fund-transfer", icon: Shuffle },
  { label: "Payments", to: "/bill-payment-center", icon: CreditCard },
  { label: "History", to: "/history", icon: History },
  { label: "Profile", to: "/profile", icon: User },
];

export default function Header() {
  const navigate = useNavigate();
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    const raw = localStorage.getItem("bf_user");
    if (raw) {
      try {
        setUser(JSON.parse(raw));
      } catch (e) {
        setUser(null);
      }
    } else setUser(null);
  }, []);

  const onLogout = () => {
    localStorage.removeItem("bf_user");
    setUser(null);
    navigate("/login");
  };

  return (
    <header className="sticky top-0 z-30 w-full backdrop-blur supports-[backdrop-filter]:bg-white/60 bg-white/80 border-b border-[hsl(var(--border))]">
      <div className="container mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-semibold text-[hsl(var(--foreground))]">
          <div className="h-8 w-8 rounded-lg bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] grid place-items-center shadow-md">
            <Banknote className="h-4 w-4" />
          </div>
          <span>BankFlow Pro</span>
        </Link>

        <nav className="hidden md:flex items-center gap-2">
          {navItems.map(({ label, to, icon: Icon }) => (
            <NavLink
              key={label}
              to={to}
              className={({ isActive }) =>
                `inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors ${
                  isActive
                    ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"
                    : "text-muted-foreground hover:bg-[hsl(var(--muted))] hover:text-[hsl(var(--muted-foreground))]"
                }`
              }
            >
              <Icon className="h-4 w-4" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `hidden md:inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm transition-colors ${
                isActive
                  ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]"
                  : "text-muted-foreground hover:bg-[hsl(var(--muted))] hover:text-[hsl(var(--muted-foreground))]"
              }`
            }
          >
            <IconSettings className="h-4 w-4" />
            Settings
          </NavLink>

          {user ? (
            <>
              <button onClick={() => navigate('/profile')} className="hidden md:inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-[hsl(var(--muted))]">
                {user.name}
              </button>
              <button onClick={onLogout} className="inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:opacity-95 shadow">
                <LogOut className="h-4 w-4" />
                Logout
              </button>
            </>
          ) : (
            <button onClick={() => navigate('/login')} className="inline-flex items-center gap-2 px-3 py-2 rounded-md text-sm bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] hover:opacity-95 shadow">
              Sign in
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
