export default function CreditScoreCard({
  score,
  max,
  grade,
  updated,
}: {
  score: number;
  max: number;
  grade: string;
  updated: string;
}) {
  const pct = Math.min(1, score / max);
  const size = 140;
  const stroke = 10;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = c * pct;

  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-base font-semibold">Credit Score</h3>
          <p className="text-xs text-muted-foreground">{updated}</p>
        </div>
      </div>
      <div className="mt-4 flex items-center gap-6">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="hsl(var(--border))" strokeWidth={stroke} fill="none" />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            stroke="hsl(var(--primary))"
            strokeWidth={stroke}
            fill="none"
            strokeDasharray={`${dash} ${c - dash}`}
            strokeLinecap="round"
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
          />
          <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" className="fill-[hsl(var(--foreground))]" fontSize="22" fontWeight="700">
            {score}
          </text>
        </svg>
        <div>
          <div className="text-2xl font-bold">{score} / {max}</div>
          <div className="text-emerald-600 font-medium">{grade}</div>
          <button className="mt-3 inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-[hsl(var(--muted))]">
            View Full Report
          </button>
        </div>
      </div>
      <div className="mt-5 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
        {[
          ["Payment History", "35%"],
          ["Credit Utilization", "30%"],
          ["Length of Credit History", "15%"],
          ["Credit Mix", "10%"],
          ["New Credit", "10%"],
        ].map(([label, value]) => (
          <div key={label} className="rounded-md border p-3">
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="font-medium">{value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
