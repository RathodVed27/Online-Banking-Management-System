import { ArrowLeftRight, History, Wallet } from "lucide-react";
import { ArrowLeftRight as IconTransfer, History as IconHistory, Wallet as IconWallet } from "lucide-react";
import { useNavigate } from "react-router-dom";

export interface Txn {
  name: string;
  amount: string;
  color?: "red" | "green";
}

export default function AccountCard({
  title,
  subtitle,
  accountNumber,
  balance,
  recentTransactions,
}: {
  title: string;
  subtitle: string;
  accountNumber: string;
  balance: string;
  recentTransactions: Txn[];
}) {
  const navigate = useNavigate();

  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">{subtitle}</p>
          <h3 className="mt-1 text-lg font-semibold">{title}</h3>
          <p className="text-sm text-muted-foreground">{accountNumber}</p>
        </div>
        <div className="h-10 w-10 rounded-md bg-[hsl(var(--muted))] grid place-items-center text-[hsl(var(--foreground))]">
          <IconWallet className="h-5 w-5" />
        </div>
      </div>
      <div className="mt-4">
        <p className="text-xs text-muted-foreground">Balance</p>
        <p className="text-2xl font-bold tracking-tight">{balance}</p>
      </div>
      <div className="mt-4 space-y-2">
        {recentTransactions.map((t, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">{t.name}</span>
            <span className={t.color === "red" ? "text-red-600" : t.color === "green" ? "text-emerald-600" : ""}>{t.amount}</span>
          </div>
        ))}
      </div>
      <div className="mt-5 flex gap-2">
        <button onClick={() => navigate('/fund-transfer')} className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-[hsl(var(--muted))]">
          <IconTransfer className="h-4 w-4" />
          Transfer
        </button>
        <button onClick={() => navigate('/history')} className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-[hsl(var(--muted))]">
          <IconHistory className="h-4 w-4" />
          History
        </button>
      </div>
    </div>
  );
}
