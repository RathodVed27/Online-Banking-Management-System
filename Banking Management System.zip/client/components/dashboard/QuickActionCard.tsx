import { ArrowLeftRight, CreditCard, Home, Smartphone } from "lucide-react";
import { ArrowLeftRight as IconTransfer, CreditCard as IconCreditCard, Home as IconHome, Smartphone as IconSmartphone } from "lucide-react";
import { useNavigate } from "react-router-dom";

const iconMap = {
  transfer: IconTransfer,
  bills: IconCreditCard,
  mobile: IconSmartphone,
  dashboard: IconHome,
} as const;

export default function QuickActionCard({
  kind,
  title,
  description,
  badge,
}: {
  kind: keyof typeof iconMap;
  title: string;
  description: string;
  badge?: string;
}) {
  const Icon = iconMap[kind];
  const navigate = useNavigate();
  return (
    <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm flex items-start gap-4">
      <div className="h-10 w-10 rounded-md bg-[hsl(var(--muted))] grid place-items-center">
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2">
          <h4 className="font-semibold">{title}</h4>
          {badge ? (
            <span className="text-[10px] uppercase tracking-wide bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded">
              {badge}
            </span>
          ) : null}
        </div>
        <p className="text-sm text-muted-foreground">{description}</p>
        <button onClick={() => {
            if (kind === 'transfer') navigate('/fund-transfer');
            else if (kind === 'bills') navigate('/bill-payment-center');
            else if (kind === 'mobile') navigate('/fund-transfer');
            else if (kind === 'dashboard') navigate('/');
          }} className="mt-3 inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-[hsl(var(--muted))]">
          {title.split(" ")[0]}
        </button>
      </div>
    </div>
  );
}
