import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";

const payees = [
  { id: "pay-1", name: "Electric Company", account: "ACCT-9821" },
  { id: "pay-2", name: "Water Utility", account: "ACCT-5533" },
  { id: "pay-3", name: "Internet Provider", account: "ACCT-1122" },
];

export default function BillPaymentCenter() {
  const [selectedPayee, setSelectedPayee] = useState(payees[0].id);
  const [fromAccount, setFromAccount] = useState("chk-1");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState<null | { payeeName: string; amount: string }>(null);

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || Number(amount) <= 0) return alert("Enter a valid amount");
    const p = payees.find((p) => p.id === selectedPayee)!;
    setSubmitted({ payeeName: p.name, amount });
    setAmount("");
    setNote("");
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold">Bill Payment Center</h1>
        <p className="text-sm text-muted-foreground mt-1">Pay your bills quickly and securely. Schedule payments in advance or pay immediately.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-1 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
            <h3 className="font-semibold">Saved Payees</h3>
            <ul className="mt-3 space-y-2 text-sm">
              {payees.map((p) => (
                <li key={p.id} className={`p-2 rounded-md hover:bg-[hsl(var(--muted))] ${selectedPayee === p.id ? "bg-[hsl(var(--muted))]" : ""}`}>
                  <button onClick={() => setSelectedPayee(p.id)} className="w-full text-left">
                    <div className="font-medium">{p.name}</div>
                    <div className="text-xs text-muted-foreground">{p.account}</div>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
            <form onSubmit={handlePay} className="space-y-4">
              <div>
                <label className="text-sm font-medium">Payee</label>
                <div className="mt-2 text-sm">{payees.find((p) => p.id === selectedPayee)?.name}</div>
              </div>

              <div>
                <label className="text-sm font-medium">From Account</label>
                <select value={fromAccount} onChange={(e) => setFromAccount(e.target.value)} className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2">
                  <option value="chk-1">Primary Checking ****1234</option>
                  <option value="sav-1">High Yield Savings ****5678</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Amount</label>
                  <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" min="0" step="0.01" placeholder="0.00" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
                </div>
                <div>
                  <label className="text-sm font-medium">Schedule Date</label>
                  <input value={date} onChange={(e) => setDate(e.target.value)} type="date" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Memo (optional)</label>
                <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Invoice # or note" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
              </div>

              <div className="flex items-center gap-3">
                <button type="submit" className="inline-flex items-center gap-2 rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] px-4 py-2 font-semibold">Pay Now</button>
                <button type="button" onClick={() => { setAmount(""); setNote(""); }} className="inline-flex items-center gap-2 rounded-md border px-4 py-2">Reset</button>
              </div>
            </form>

            {submitted ? (
              <div className="mt-4 rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3">
                <p className="font-medium">Payment Scheduled</p>
                <p className="text-sm text-muted-foreground">{`To: ${submitted.payeeName}`}</p>
                <p className="text-sm text-muted-foreground">{`Amount: $${Number(submitted.amount).toFixed(2)}`}</p>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
