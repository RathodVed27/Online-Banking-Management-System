import { useMemo, useState } from "react";
import AppLayout from "@/components/layout/AppLayout";

type Txn = { id: string; date: string; account: string; description: string; amount: number; type: "debit" | "credit" };

const ALL_TXNS: Txn[] = [
  { id: "t1", date: "2025-10-07", account: "Primary Checking ****1234", description: "Grocery Store", amount: -87.45, type: "debit" },
  { id: "t2", date: "2025-10-06", account: "High Yield Savings ****5678", description: "Interest Payment", amount: 15.75, type: "credit" },
  { id: "t3", date: "2025-10-05", account: "Primary Checking ****1234", description: "Direct Deposit", amount: 2450.0, type: "credit" },
  { id: "t4", date: "2025-10-04", account: "Rewards Credit Card ****9012", description: "Online Purchase", amount: -125.99, type: "debit" },
  { id: "t5", date: "2025-09-30", account: "Primary Checking ****1234", description: "Gas Station", amount: -45.2, type: "debit" },
];

export default function History() {
  const [account, setAccount] = useState("all");
  const [query, setQuery] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const txns = useMemo(() => {
    return ALL_TXNS.filter((t) => {
      if (account !== "all" && t.account !== account) return false;
      if (query && !(`${t.description}`.toLowerCase().includes(query.toLowerCase()) || t.id.includes(query))) return false;
      if (startDate && t.date < startDate) return false;
      if (endDate && t.date > endDate) return false;
      return true;
    }).sort((a,b) => b.date.localeCompare(a.date));
  }, [account, query, startDate, endDate]);

  const exportCSV = () => {
    const headers = ["id","date","account","description","amount"];
    const rows = txns.map(t => [t.id,t.date,t.account,t.description,t.amount].join(","));
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transactions_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Transaction History</h1>
            <p className="text-sm text-muted-foreground mt-1">Review recent transactions across your accounts.</p>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={exportCSV} className="rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] px-3 py-2 text-sm">Export CSV</button>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-3 grid grid-cols-1 gap-3">
            <div className="flex gap-2">
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search description or id" className="flex-1 rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
              <select value={account} onChange={(e) => setAccount(e.target.value)} className="rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2">
                <option value="all">All accounts</option>
                <option value="Primary Checking ****1234">Primary Checking ****1234</option>
                <option value="High Yield Savings ****5678">High Yield Savings ****5678</option>
                <option value="Rewards Credit Card ****9012">Rewards Credit Card ****9012</option>
              </select>
            </div>

            <div className="mt-2 overflow-hidden rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))]">
              <table className="w-full text-sm">
                <thead className="bg-[hsl(var(--sidebar-accent))] text-[hsl(var(--sidebar-accent-foreground))]">
                  <tr>
                    <th className="text-left px-4 py-2">Date</th>
                    <th className="text-left px-4 py-2">Account</th>
                    <th className="text-left px-4 py-2">Description</th>
                    <th className="text-right px-4 py-2">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {txns.map(t => (
                    <tr key={t.id} className="border-t">
                      <td className="px-4 py-3">{t.date}</td>
                      <td className="px-4 py-3">{t.account}</td>
                      <td className="px-4 py-3">{t.description}</td>
                      <td className={`px-4 py-3 text-right ${t.amount < 0 ? 'text-red-600' : 'text-emerald-600'}`}>${Math.abs(t.amount).toFixed(2)}</td>
                    </tr>
                  ))}
                  {txns.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="p-6 text-center text-muted-foreground">No transactions found</td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>

          <aside className="md:col-span-1">
            <div className="rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
              <h4 className="font-semibold">Filters</h4>
              <label className="block mt-3 text-xs">Start date</label>
              <input type="date" value={startDate} onChange={(e)=>setStartDate(e.target.value)} className="mt-1 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
              <label className="block mt-3 text-xs">End date</label>
              <input type="date" value={endDate} onChange={(e)=>setEndDate(e.target.value)} className="mt-1 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
              <button onClick={() => { setStartDate(''); setEndDate(''); setQuery(''); setAccount('all'); }} className="mt-4 w-full rounded-md border px-3 py-2">Reset</button>
            </div>
          </aside>
        </div>
      </div>
    </AppLayout>
  );
}
