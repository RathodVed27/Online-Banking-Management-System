import AppLayout from "@/components/layout/AppLayout";
import AccountCard from "@/components/dashboard/AccountCard";
import CreditScoreCard from "@/components/dashboard/CreditScoreCard";
import QuickActionCard from "@/components/dashboard/QuickActionCard";
import { RotateCw } from "lucide-react";

export default function Index() {
  return (
    <AppLayout>
      {/* Greeting */}
      <section className="mb-6">
        <p className="text-sm text-muted-foreground">Welcome back to your dashboard</p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight">Good morning, Sarah Johnson</h1>
      </section>

      {/* Overview */}
      <section className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm md:col-span-2 relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none" style={{background: "linear-gradient(135deg, rgba(30,58,138,.03) 0%, rgba(30,58,138,.12) 100%)"}} />
          <div className="relative z-10 flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Total Balance</p>
              <p className="mt-1 text-3xl font-bold tracking-tight">$16,068.39</p>
            </div>
            <button className="inline-flex items-center gap-2 rounded-md border px-3 py-2 text-sm hover:bg-[hsl(var(--muted))]">
              <RotateCw className="h-4 w-4" />
              Refresh
            </button>
          </div>
        </div>
        <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">Account Summary</p>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-3 text-center">
            <div className="rounded-md border p-3">
              <p className="text-xs text-muted-foreground">Member Since</p>
              <p className="font-semibold">2019</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs text-muted-foreground">Active Accounts</p>
              <p className="font-semibold">3</p>
            </div>
            <div className="rounded-md border p-3">
              <p className="text-xs text-muted-foreground">Last Login</p>
              <p className="font-semibold">Oct 7, 2025</p>
            </div>
          </div>
        </div>
      </section>

      {/* Main grid */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Your Accounts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AccountCard
              title="Primary Checking"
              subtitle="Available Balance"
              accountNumber="****1234"
              balance="$4,567.89"
              recentTransactions={[
                { name: "Direct Deposit", amount: "+$2,450.00", color: "green" },
                { name: "Grocery Store", amount: "-$87.45", color: "red" },
                { name: "Gas Station", amount: "-$45.20", color: "red" },
              ]}
            />
            <AccountCard
              title="High Yield Savings"
              subtitle="Available Balance"
              accountNumber="****5678"
              balance="$12,750.50"
              recentTransactions={[
                { name: "Interest Payment", amount: "+$15.75", color: "green" },
                { name: "Transfer to Checking", amount: "-$500.00", color: "red" },
                { name: "Monthly Deposit", amount: "+$1,000.00", color: "green" },
              ]}
            />
            <AccountCard
              title="Rewards Credit Card"
              subtitle="Available Credit"
              accountNumber="****9012"
              balance="$1,250.00"
              recentTransactions={[
                { name: "Online Purchase", amount: "-$125.99", color: "red" },
              ]}
            />
          </div>

          {/* Quick Actions */}
          <div>
            <h2 className="mb-3 text-lg font-semibold">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <QuickActionCard kind="transfer" title="Transfer Funds" description="Move money between your accounts instantly" />
              <QuickActionCard kind="bills" title="Pay Bills" description="Pay your bills quickly and securely" />
              <QuickActionCard kind="mobile" title="Mobile Deposit" description="Deposit checks using your mobile device" badge="New" />
              <QuickActionCard kind="dashboard" title="Dashboard" description="Go to main dashboard" />
            </div>
          </div>
        </div>
        <div className="space-y-6">
          <CreditScoreCard score={742} max={850} grade="Excellent" updated="Updated Oct 1, 2025" />

          {/* Financial Insights */}
          <div className="rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-5 shadow-sm">
            <h3 className="text-base font-semibold">Financial Insights</h3>
            <div className="mt-4 space-y-4">
              <div>
                <div className="flex items-center justify-between text-sm">
                  <p className="text-muted-foreground">Monthly Spending</p>
                  <p className="font-medium">$2,847.50</p>
                </div>
                <div className="mt-2 h-2 rounded-full bg-[hsl(var(--muted))]">
                  <div className="h-full w-[89%] rounded-full bg-emerald-600" />
                </div>
                <p className="mt-1 text-xs text-muted-foreground">89% of budget</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-2">Top Categories</p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span>Groceries</span>
                    <span className="text-muted-foreground">$485.20</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Internet Service</span>
                    <span className="text-muted-foreground">$89.99</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </AppLayout>
  );
}
