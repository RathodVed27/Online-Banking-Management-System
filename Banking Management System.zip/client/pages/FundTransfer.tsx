import { useState } from "react";
import AppLayout from "@/components/layout/AppLayout";

const accounts = [
  { id: "chk-1", name: "Primary Checking ****1234", balance: 4567.89 },
  { id: "sav-1", name: "High Yield Savings ****5678", balance: 12750.5 },
  { id: "cc-1", name: "Rewards Credit Card ****9012", balance: 1250.0 },
];

export default function FundTransfer() {
  const [from, setFrom] = useState(accounts[0].id);
  const [to, setTo] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState("");
  const [submitted, setSubmitted] = useState<null | { from: string; to: string; amount: string }>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!to || !amount || Number(amount) <= 0) {
      return alert("Please provide a valid recipient and amount.");
    }
    setSubmitted({ from: accounts.find((a) => a.id === from)!.name, to, amount });
    setTo("");
    setAmount("");
    setNote("");
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold">Fund Transfer</h1>
        <p className="text-sm text-muted-foreground mt-1">Send money securely between your accounts or to an external recipient.</p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium">From</label>
            <select value={from} onChange={(e) => setFrom(e.target.value)} className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2">
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>{`${a.name} — $${a.balance.toLocaleString()}`}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium">To (Account or Email)</label>
            <input value={to} onChange={(e) => setTo(e.target.value)} placeholder="Recipient account number or email" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Amount</label>
              <input value={amount} onChange={(e) => setAmount(e.target.value)} type="number" min="0" step="0.01" placeholder="0.00" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
            </div>
            <div>
              <label className="text-sm font-medium">Schedule Date</label>
              <input value={date} onChange={(e) => setDate(e.target.value)} type="date" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium">Note (optional)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g., Rent for May" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div className="flex items-center gap-3">
            <button type="submit" className="inline-flex items-center gap-2 rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] px-4 py-2 font-semibold">Transfer</button>
            <button type="button" onClick={() => { setTo(""); setAmount(""); setNote(""); }} className="inline-flex items-center gap-2 rounded-md border px-4 py-2">Reset</button>
          </div>
        </form>

        {submitted ? (
          <div className="mt-6 rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
            <h3 className="font-semibold">Transfer Submitted</h3>
            <p className="text-sm text-muted-foreground mt-1">{`From: ${submitted.from}`}</p>
            <p className="text-sm text-muted-foreground">{`To: ${submitted.to}`}</p>
            <p className="text-sm text-muted-foreground">{`Amount: $${Number(submitted.amount).toFixed(2)}`}</p>
          </div>
        ) : null}
      </div>
    </AppLayout>
  );
}
