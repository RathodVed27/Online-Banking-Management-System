import AppLayout from "@/components/layout/AppLayout";

export default function Placeholder({ title }: { title: string }) {
  return (
    <AppLayout>
      <div className="min-h-[40vh] grid place-items-center">
        <div className="text-center max-w-xl">
          <h1 className="text-3xl font-bold">{title}</h1>
          <p className="mt-2 text-muted-foreground">
            This page is a placeholder. Tell Fusion what you want here and we’ll build it next.
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
