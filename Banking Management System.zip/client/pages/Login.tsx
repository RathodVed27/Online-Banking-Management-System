import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return alert("Enter an email");
    // Simple client-side auth simulation
    const user = { name: email.split("@")[0].replace(/[.]/g, " "), email };
    localStorage.setItem("bf_user", JSON.stringify(user));
    navigate("/");
  };

  return (
    <AppLayout>
      <div className="max-w-md mx-auto">
        <h1 className="text-2xl font-bold">Sign in</h1>
        <p className="text-sm text-muted-foreground mt-1">Sign in to access your BankFlow Pro account.</p>

        <form onSubmit={handleLogin} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>
          <div>
            <label className="text-sm font-medium">Password</label>
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div className="flex items-center gap-3">
            <button type="submit" className="inline-flex items-center gap-2 rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] px-4 py-2 font-semibold">Sign in</button>
            <button type="button" onClick={() => { setEmail(""); setPassword(""); }} className="inline-flex items-center gap-2 rounded-md border px-4 py-2">Clear</button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
