import { useEffect, useState } from "react";
import AppLayout from "@/components/layout/AppLayout";

export default function Settings() {
  const [dark, setDark] = useState(() => localStorage.getItem("bf_theme") === "dark");

  useEffect(() => {
    if (dark) document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
    localStorage.setItem("bf_theme", dark ? "dark" : "light");
  }, [dark]);

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground mt-1">Customize your experience.</p>

        <div className="mt-6 space-y-4">
          <div className="rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
            <h3 className="font-semibold">Appearance</h3>
            <div className="mt-3 flex items-center justify-between">
              <div>
                <p className="font-medium">Theme</p>
                <p className="text-sm text-muted-foreground">Switch between light and dark modes</p>
              </div>
              <div>
                <button onClick={() => setDark(!dark)} className={`px-3 py-2 rounded-md border ${dark ? 'bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]' : ''}`}>
                  {dark ? 'Dark' : 'Light'}
                </button>
              </div>
            </div>
          </div>

          <div className="rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
            <h3 className="font-semibold">Account</h3>
            <p className="mt-2 text-sm text-muted-foreground">Manage account preferences in the profile page.</p>
            <div className="mt-3 flex gap-2">
              <button onClick={() => alert('Open profile settings')} className="rounded-md border px-3 py-2">Open Profile</button>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
