import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AppLayout from "@/components/layout/AppLayout";

export default function Profile() {
  const navigate = useNavigate();
  const [name, setName] = useState("Sarah Johnson");
  const [email, setEmail] = useState("sarah.johnson@example.com");
  const [phone, setPhone] = useState("(555) 123-4567");

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const user = { name, email };
    localStorage.setItem('bf_user', JSON.stringify(user));
    alert("Profile saved");
  };

  return (
    <AppLayout>
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Profile</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your personal information and account settings.</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="mt-6 space-y-4">
          <div>
            <label className="text-sm font-medium">Full name</label>
            <input value={name} onChange={(e)=>setName(e.target.value)} className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div>
            <label className="text-sm font-medium">Email</label>
            <input value={email} onChange={(e)=>setEmail(e.target.value)} className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div>
            <label className="text-sm font-medium">Phone</label>
            <input value={phone} onChange={(e)=>setPhone(e.target.value)} className="mt-2 w-full rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] px-3 py-2" />
          </div>

          <div className="flex items-center gap-3">
            <button type="submit" className="inline-flex items-center gap-2 rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))] px-4 py-2 font-semibold">Save</button>
            <button type="button" onClick={() => navigate('/')} className="inline-flex items-center gap-2 rounded-md border px-4 py-2">Back</button>
          </div>
        </form>

        <div className="mt-6 rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-4">
          <h3 className="font-semibold">Account</h3>
          <div className="mt-2 text-sm text-muted-foreground">Member since 2019</div>
          <div className="mt-3 flex gap-2">
            <button onClick={() => { alert('Manage profile (UI-only)') }} className="rounded-md border px-3 py-2">Manage Profile</button>
            <button onClick={() => { navigate('/'); alert('Logged out (UI-only)'); }} className="rounded-md bg-[hsl(var(--destructive))] text-[hsl(var(--destructive-foreground))] px-3 py-2">Logout</button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
