import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Placeholder from "./pages/Placeholder";
import FundTransfer from "./pages/FundTransfer";
import BillPaymentCenter from "./pages/BillPaymentCenter";
import History from "./pages/History";
import Profile from "./pages/Profile";
import Login from "./pages/Login";
import Settings from "./pages/Settings";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/transfers" element={<Placeholder title="Transfers" />} />
          <Route path="/payments" element={<Placeholder title="Payments" />} />
          <Route path="/fund-transfer" element={<FundTransfer />} />
          <Route path="/bill-payment-center" element={<BillPaymentCenter />} />
          <Route path="/history" element={<History />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/login" element={<Login />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

declare global {
  interface Window {
    __bankflow_root?: any;
  }
}

if (!window.__bankflow_root) {
  window.__bankflow_root = createRoot(document.getElementById("root")!);
}

window.__bankflow_root.render(<App />);
